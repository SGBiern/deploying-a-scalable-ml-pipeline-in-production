import setuptools

setuptools.setup(
    name="starter",
    version="0.0.0",
    description="Starter code.",
    author="SGBiern",
)
